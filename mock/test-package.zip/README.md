# Test Package

This is a minimal test problem package used for validating the problem registration endpoint.

## Structure

- `config.json` - Problem configuration
- `Dockerfile` - Container definition
- `hooks/` - Pre and post evaluation hooks

## Purpose

This package is used to test:

- Problem package upload and extraction
- Configuration validation
- Docker image building
- Basic hook execution
