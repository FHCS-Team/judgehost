#!/bin/bash
# Pre-evaluation setup hook

set -e

echo "[PRE] Setting up test environment..."
echo "[PRE] Problem ID: ${PROBLEM_ID:-unknown}"
echo "[PRE] Submission ID: ${SUBMISSION_ID:-unknown}"
echo "[PRE] Setup complete"

exit 0
