#!/usr/bin/env python3
"""Generate sample database for SQL optimization challenge"""

import psycopg2
import random
from datetime import datetime, timedelta
import json
import sys

try:
    # Connect to database
    conn = psycopg2.connect(
        host="localhost",
        database="hackathon_db",
        user="judge",
        password="judgepass"
    )
    cur = conn.cursor()

    print("[DATA] Generating sample data (10k records)...")

    # Generate users (1000)
    print("[DATA] Generating users...")
    countries = ['US', 'VN', 'JP', 'KR', 'CN', 'IN', 'GB', 'FR', 'DE', 'CA']
    plans = ['free', 'basic', 'pro', 'enterprise']

    users = []
    for i in range(1, 1001):
        signup_ts = datetime.now() - timedelta(days=random.randint(1, 365))
        country = random.choice(countries)
        plan = random.choice(plans)
        users.append((i, signup_ts, country, plan))

    cur.executemany(
        "INSERT INTO users (user_id, signup_ts, country, plan) VALUES (%s, %s, %s, %s)",
        users
    )

    # Generate devices (500)
    print("[DATA] Generating devices...")
    device_types = ['mobile', 'tablet', 'desktop', 'smartwatch', 'tv']
    os_versions = ['iOS 15', 'iOS 16', 'Android 11', 'Android 12', 'Android 13']

    devices = []
    for i in range(1, 501):
        device_type = random.choice(device_types)
        os_version = random.choice(os_versions)
        devices.append((i, device_type, os_version))

    cur.executemany(
        "INSERT INTO devices (device_id, device_type, os_version) VALUES (%s, %s, %s)",
        devices
    )

    # Generate events (10000)
    print("[DATA] Generating events...")
    event_types = ['page_view', 'click', 'purchase', 'login', 'logout', 
                   'search', 'add_to_cart', 'checkout', 'signup']

    events = []
    for i in range(1, 10001):
        user_id = random.randint(1, 1000)
        device_id = random.randint(1, 500) if random.random() > 0.1 else None
        event_type = random.choice(event_types)
        event_ts = datetime.now() - timedelta(
            days=random.randint(0, 180),
            hours=random.randint(0, 23),
            minutes=random.randint(0, 59)
        )
        
        payload = {
            'flag': random.choice(['true', 'false']),
            'value': random.randint(1, 1000),
            'category': random.choice(['A', 'B', 'C', 'D'])
        }
        
        events.append((user_id, device_id, event_type, event_ts, json.dumps(payload)))

    cur.executemany(
        "INSERT INTO events (user_id, device_id, event_type, event_ts, payload) VALUES (%s, %s, %s, %s, %s)",
        events
    )

    conn.commit()
    cur.close()
    conn.close()

    print("[DATA] Sample data generation complete!")
    print(f"[DATA] Total: {len(users)} users, {len(devices)} devices, {len(events)} events")

except Exception as e:
    print(f"[ERROR] Failed to generate data: {e}", file=sys.stderr)
    sys.exit(1)
